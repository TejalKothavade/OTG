package com.example.Service.ServiceImpl;

import com.example.Entity.Item;
import com.example.Repository.ItemRepo;
import com.example.Service.ItemService;
import com.example.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ItemSeviceImpl implements ItemService {

    @Autowired
    private ItemRepo itemRepo;

    @Override
    public Item storeItem(Item item) {
        return itemRepo.save(item);
    }

    @Override
    public List<Item> getallItem() {
        return itemRepo.findAll();
    }

    @Override
    public Item findbyname(String name) throws ResourceNotFoundException {
        Optional<Item> item = itemRepo.findByName(name);

        if (item.isPresent()) {
            return item.get();
        }
        throw new ResourceNotFoundException("Item: " + name + " not found!!!");
    }
}
