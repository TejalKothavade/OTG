package com.example.Controller;

import com.example.Entity.Item;
import com.example.Service.ItemService;
import com.example.exception.ResourceNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController

public class ItemController {
    @Autowired
    private ItemService itemService;

    @PostMapping("/item")
    public ResponseEntity<Item> register(@RequestBody Item item) {
        return new ResponseEntity<Item>(itemService.storeItem(item), HttpStatus.CREATED);
    }

    @GetMapping("/item")
    public List<Item> showall() {
        return itemService.getallItem();

    }

    @GetMapping("item/{itemName}")
    public ResponseEntity<Item> findbyname(@PathVariable String itemName) throws ResourceNotFoundException {
        return new ResponseEntity<Item>(itemService.findbyname(itemName), HttpStatus.OK);

    }


}
