package com.example.Controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FallbackController {

	@GetMapping("/customerServicefallback")
	public String CustomerServiceFallback() {
		return "CustomerService is Down At this Time";
		
	}
	
	@GetMapping("/itemServicefallback")
	public String ItemServiceFallback() {
		return "ItemService is Down At this Time";
		
	}
	
	@GetMapping("/salesOrdeServicefallback")
	public String SalesOrderServiceFallback() {
		return "SalesOrderService is Down At this Time";
		
	}
}
