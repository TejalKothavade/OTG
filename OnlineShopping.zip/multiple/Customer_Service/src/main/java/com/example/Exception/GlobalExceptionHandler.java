package com.example.Exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(ResourcesNotFoundException.class)
	public ResponseEntity<ErrorResponse> resourceNotFoundExceptionhandler(ResourcesNotFoundException ex, WebRequest request){
		String message=ex.getLocalizedMessage();
		ErrorResponse errorResponse=new ErrorResponse(message);
		return new ResponseEntity<ErrorResponse>(errorResponse,HttpStatus.NOT_FOUND);
		
	}


}
