package com.example.event;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name="CustomerSos")
public class CustomerCreatedEvent{
	@Id
	private int custId;
	private String custFirstName;
	private String custLastName;
	private String custEmail;
}
