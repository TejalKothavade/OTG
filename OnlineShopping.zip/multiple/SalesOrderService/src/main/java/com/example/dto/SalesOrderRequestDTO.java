package com.example.dto;

import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class SalesOrderRequestDTO {
    private String orderDescription;
    private String orderDate;
    private int custID;
    private List<String> listItems;
    
    
	public String getOrderDate() {
		return orderDate;
	}


	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}


	public int getCustID() {
		return custID;
	}


	public void setCustID(int custID) {
		this.custID = custID;
	}


	public List<String> getListItems() {
		return listItems;
	}


	public void setListItems(List<String> listItems) {
		this.listItems = listItems;
	}


	public String getOrderDescription() {
		// TODO Auto-generated method stub
		return null;
	}


	
}
