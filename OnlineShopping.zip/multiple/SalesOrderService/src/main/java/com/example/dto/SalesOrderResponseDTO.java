package com.example.dto;

import com.example.entity.OrderLineItem;
import lombok.Data;

import java.util.List;

@Data
public class SalesOrderResponseDTO {
    private long orderId;
    private String orderDescription;
    private List<OrderLineItemDTO> orderLineItemsList;
	public long getOrderId() {
		return orderId;
	}
	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}
	public String getOrderDescription() {
		return orderDescription;
	}
	public void setOrderDescription(String orderDescription) {
		this.orderDescription = orderDescription;
	}
	public List<OrderLineItemDTO> getOrderLineItemsList() {
		return orderLineItemsList;
	}
	public void setOrderLineItemsList(List<OrderLineItemDTO> orderLineItemsList) {
		this.orderLineItemsList = orderLineItemsList;
	}
    
    
}
