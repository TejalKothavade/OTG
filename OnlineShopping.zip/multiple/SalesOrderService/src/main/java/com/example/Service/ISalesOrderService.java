package com.example.Service;

import java.util.List;

import com.example.dto.Item;
import com.example.dto.SalesOrderRequestDTO;
import com.example.dto.SalesOrderResponseDTO;
import com.example.entity.SalesOrder;

public interface ISalesOrderService {
    Item findItemByName(String name) throws Exception;

    SalesOrderResponseDTO createOrder(SalesOrderRequestDTO salesOrderRequestDTO) throws Exception;
    
    List<SalesOrder> all();
    
//    public Optional<SalesOrder> get(long id);
//
    }
