package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.Service.CustomerService;
import com.example.Service.ISalesOrderService;
import com.example.dto.SalesOrderRequestDTO;
import com.example.dto.SalesOrderResponseDTO;
import com.example.entity.SalesOrder;
import com.example.event.CustomerCreatedEvent;

@RestController
@RequestMapping("/salesorder")
public class SalesOrderController {

	@Autowired
	private CustomerService customerService;

	@Autowired
	private ISalesOrderService salesOrderService;
	
//	@GetMapping("/fetchCustomerData")
//	public void fetchCustomerData() {
//		saleOrderService.subscribeToCustomerCreatedEvent();
//	}s
	
	@PostMapping("/savedata")
	public String saveData(@RequestBody CustomerCreatedEvent customerCreatedEvent) {
		customerService.subscribeToCustomerCreatedEvent(customerCreatedEvent);
		return "customer data successfully saved";
	}

	@PostMapping("/orders")
	public ResponseEntity<SalesOrderResponseDTO> saveData(@RequestBody SalesOrderRequestDTO salesOrderRequestDTO) throws Exception {
		SalesOrderResponseDTO salesOrderResponseDTO = salesOrderService.createOrder(salesOrderRequestDTO);
		return new ResponseEntity<>(salesOrderResponseDTO, HttpStatus.CREATED);
	}

	
	@GetMapping("/{name}")
	public ResponseEntity<?> getItemByName(@PathVariable String name) throws Exception {
		return ResponseEntity.ok(salesOrderService.findItemByName(name));
	}
	
	@ResponseStatus(HttpStatus.OK)
	@GetMapping("/")
	public List<SalesOrder> all() {
		return salesOrderService.all();
	}

//	@ResponseStatus(HttpStatus.OK)
//	@GetMapping("/{id}")
//	public ResponseEntity<Optional<SalesOrder>>  get(@PathVariable long id) {
//		return new ResponseEntity<Optional<SalesOrder>>( salesOrderService.get(id),HttpStatus.OK);
//	}
	
	


}
